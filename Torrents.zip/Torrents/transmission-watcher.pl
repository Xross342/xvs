#!/usr/bin/perl
use strict;

use lib '..';
use lib '../Modules/';

use XFSConfig;
use XUpload;
use Fcntl qw( :flock :DEFAULT );
use Cwd qw(abs_path);
use File::Basename;
use Digest::MD5 qw(md5_hex);

$ENV{PERL_LWP_SSL_VERIFY_HOSTNAME} = 0;

use LWP::UserAgent;
use TransmissionRPC;
use Data::Dumper;

#exit unless $c->{fs_key};
exit unless sysopen( PID, 'transmission-watcher.pid', O_RDONLY | O_CREAT ) && flock( PID, LOCK_EX | LOCK_NB );
my $rpc = TransmissionRPC->new($c->{transmission_endpoint} || 'http://127.0.0.1:9091/transmission/rpc/');
my $ua = LWP::UserAgent->new(agent => 'Transmission-Watcher');
#$ua->ssl_opts(verify_hostname => 0,
#              SSL_verify_mode => 0x00);
              
while(1) {
   sleep(2);

   my $ret = eval {
      $rpc->request('torrent-get', {
         fields => ["id","name","activityDate","addedDate","percentDone","hashString","error","errorString","eta","uploadedEver","isFinished","sizeWhenDone","leftUntilDone","peersConnected","peersGettingFromUs","peersSendingToUs","percentDone","rateDownload","rateUpload","status","trackers","downloadDir","files","uploadRatio"],
      })
   };

   print Dumper($ret);

   (print"not running\n$@"), sleep(2), next if !$ret;
   sleep(2),next if $ret->{result} ne 'success';
   
   my @working_torrents = @{ $ret->{arguments}->{torrents} } if ref($ret->{arguments}->{torrents}) eq 'ARRAY';
   if($#working_torrents==-1)
   {
	my $res = $ua->post("$c->{site_url}/fs", {
		op => 'torrent_stats',
		dl_key => $c->{dl_key},
		host_id => $c->{host_id},
		data => '[]',
		ping => 1
   		})->content;
	print"PING:$res\n";
	sleep(2);
	next;
   }

   my %by_infohash;
   $by_infohash{$_->{hashString}} = $_ for (@working_torrents);

   my $progress_ret = sendProgress(@working_torrents);
   my @to_delete = map { $by_infohash{$_} } @{ $progress_ret->{deleted_torrents} } if $progress_ret->{deleted_torrents};
   delete($by_infohash{$_->{hashString}}) for @to_delete;

   my @to_import = grep { $by_infohash{$_->{hashString}} && $_->{status} == 6 } @working_torrents;

   #print Dumper(\@working_torrents, \@to_delete, \@to_import);
   print("To import:".Dumper(\@to_import)) if @to_import;

   massDelete(@to_delete) if @to_delete;
   massImport(@to_import) if @to_import;
}

sub sendProgress {
   my @reports;

   for (@_) {
      push @reports, {
         name => $_->{name},
         total_done => $_->{sizeWhenDone} - $_->{leftUntilDone},
         total_uploaded => $_->{uploadedEver},
         download_rate => $_->{rateDownload},
         upload_rate => $_->{rateUpload},
         total_wanted => $_->{sizeWhenDone},
         files => $_->{files},
         info_hash => $_->{hashString},
         peers => $_->{peersSendingToUs},
         updated => $_->{activityDate},
      };
   }

   my $data = JSON::encode_json(\@reports);
   print "Sending torrent stats to XFileSharingPro Main Server: $data\n";

   my $res = $ua->post("$c->{site_url}/fs", {
      op => 'torrent_stats',
      dl_key => $c->{dl_key},
      host_id => $c->{host_id},
      data => $data,
   });

   my $ret = eval { JSON::decode_json($res->decoded_content) };
   print "Received response stats:", $res->decoded_content, "\n";
   die($@) if !$ret;

   return $ret;
}

sub massDelete {
   my @hash_strings = map { $_->{hashString} } @_;
   print STDERR "The following torrents are marked as missing in the database, deleting: @hash_strings\n";

   my $ret = $rpc->request('torrent-remove', {
      ids => @hash_strings,
      'delete-local-data' => JSON::true,
   });

   rmdir("$c->{cgi_dir}/Torrents/workdir/$_") for @hash_strings;

   print "Received response: ", JSON::encode_json($ret), "\n";
}

sub massImport
{
	for(@_)
	{
		print "Importing task $_->{hashString} ($c->{cgi_dir}/Torrents/workdir/$_->{hashString})\n";

		XUpload::ImportDir("$c->{cgi_dir}/Torrents/workdir/$_->{hashString}", sid => $_->{hashString} );

		my $res = $ua->post("$c->{site_url}/fs", {
		 op => 'torrent_done',
		 fs_key => $c->{dl_key},
		 host_id => $c->{host_id},
		 sid => $_->{hashString},
		});
		print "torrent_done response:", $res->decoded_content, "\n";
	}
}
